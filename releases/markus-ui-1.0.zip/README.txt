MarkUs UI Library v1.0
Released on June 6th, 2014.

To see examples, please go to http://echeung.me/markus-style/
All resources are available at https://github.com/arkon94/markus-style