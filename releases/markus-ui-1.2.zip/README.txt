MarkUs UI Library v1.2
Released on August 29th, 2014.

To see examples, please go to http://echeung.me/markus-style/
All resources are available at https://github.com/arkon/markus-style