MarkUs UI Library v1.1
Released on June 11th, 2014.

To see examples, please go to http://echeung.me/markus-style/
All resources are available at https://github.com/arkon94/markus-style